// next.config.ts
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // No experimental flags needed right now
};

export default nextConfig;
